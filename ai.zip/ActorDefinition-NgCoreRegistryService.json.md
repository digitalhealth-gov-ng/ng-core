# NG Registry Service - JSON Representation - Nigeria Core - FHIR Implementation Guide v0.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NG Registry Service**

## : NG Registry Service - JSON Representation

| |
| :--- |
| Draft as of 2026-08-17 |

[Raw json](ActorDefinition-NgCoreRegistryService.json) | [Download](ActorDefinition-NgCoreRegistryService.json)

