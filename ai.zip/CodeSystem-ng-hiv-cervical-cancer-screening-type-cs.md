# HIV Cervical Cancer Screening Type - Nigeria Core - FHIR Implementation Guide v0.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HIV Cervical Cancer Screening Type**

## CodeSystem: HIV Cervical Cancer Screening Type 

| | |
| :--- | :--- |
| *Official URL*:https://fhir-ig.digitalhealth.gov.ng/CodeSystem/ng-hiv-cervical-cancer-screening-type-cs | *Version*:0.0.0 |
| Active as of 2026-08-12 | *Computable Name*:NgHivCervicalCancerScreeningTypeCS |
| *Other Identifiers:*OID:2.16.840.1.113884.3.9944.1.16.38 | |

 
Codes used for representing the cervical screening type. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [NgHivCervicalCancerScreeningTypeVS](ValueSet-ng-hiv-cervical-cancer-screening-type-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ng-hiv-cervical-cancer-screening-type-cs",
  "url" : "https://fhir-ig.digitalhealth.gov.ng/CodeSystem/ng-hiv-cervical-cancer-screening-type-cs",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113884.3.9944.1.16.38"
  }],
  "version" : "0.0.0",
  "name" : "NgHivCervicalCancerScreeningTypeCS",
  "title" : "HIV Cervical Cancer Screening Type",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-12T13:22:49+01:00",
  "publisher" : "NDHI",
  "contact" : [{
    "name" : "NDHI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://digitalhealth.gov.ng"
    },
    {
      "system" : "email",
      "value" : "emeka2015@gmail.com"
    }]
  },
  {
    "name" : "Nigeria Digital in Health Initiative.",
    "telecom" : [{
      "system" : "email",
      "value" : "lekeojewale@gmail.com",
      "use" : "work"
    }]
  },
  {
    "name" : "Nigeria Digital in Health Initiative.",
    "telecom" : [{
      "system" : "email",
      "value" : "emeka2015@gmail.com",
      "use" : "work"
    }]
  }],
  "description" : "Codes used for representing the cervical screening type.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "NG",
      "display" : "Nigeria"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 2,
  "concept" : [{
    "code" : "Routine-Screening-previous-result-negative",
    "display" : "Routine screening (Previously negative screening result)"
  },
  {
    "code" : "post-treatment-follow-up-screening",
    "display" : "Post treatment follow-up screening"
  }]
}

```
