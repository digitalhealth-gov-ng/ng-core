# NG Conformance and Sandbox Service - JSON Representation - Nigeria Core - FHIR Implementation Guide v0.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NG Conformance and Sandbox Service**

## : NG Conformance and Sandbox Service - JSON Representation

| |
| :--- |
| Active as of 2026-08-17 |

[Raw json](ActorDefinition-NgCoreConformanceSandboxService.json) | [Download](ActorDefinition-NgCoreConformanceSandboxService.json)

