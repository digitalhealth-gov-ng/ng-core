# Home - Nigeria Core - FHIR Implementation Guide v0.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir-ig.digitalhealth.gov.ng/ImplementationGuide/ng.gov.digitalhealth.fhir-ig | *Version*:0.0.0 |
| Draft as of 2026-07-10 | *Computable Name*:NigeriaCore |
| *Other Identifiers:*OID:2.16.840.1.113884.3.9944.1 | |

### Introduction

This implementation guide is under active development (version 0.0.0) and is not yet a final, normative release.

The Nigeria Core FHIR Implementation Guide provides the national foundation for standards-based health information exchange in Nigeria. It defines a reusable minimum set of FHIR profiles, extensions, terminology bindings, identifiers, RESTful interactions, and implementation expectations for government institutions, health programmes, regulators, healthcare providers, registries, vendors, and other digital health platforms.

Nigeria Core serves as the common interoperability **floor** for Nigeria's digital health ecosystem. It supports consistent exchange across electronic medical records, community health systems, laboratories, pharmacies, insurance and claims platforms, logistics systems, analytics platforms, registries, shared health records, and health information exchanges.

The guide is developed under the digital health leadership of the Federal Ministry of Health and Social Welfare, the National Digital Health Architecture, and the Nigeria Digital in Health Initiative (NDHI). It recognises Nigeria's decentralised health system, in which national institutions, states, programmes, regulators, facilities, and private platforms may operate different systems while using a common standards framework.

Nigeria Core is based on [FHIR Version R4](http://hl7.org/fhir/R4/). Programme-specific and domain-specific implementation guides may add further constraints and workflows but should build on Nigeria Core wherever applicable.

### What Nigeria Core Enables

* Harmonised health data structures, identifiers, terminology, and APIs
* Reusable profiles and terminology across programmes and jurisdictions
* Interoperability among national, state, provider, regulator, and vendor systems
* Standards-based procurement, implementation, and vendor alignment
* Conformance testing, sandbox validation, and implementation support
* Integration with registries, shared services, and health information exchanges
* Alignment with relevant Nigerian and international standards

The guide provides a foundation for eCHIS, MNCH, HIV, tuberculosis, malaria, immunization, family planning, nutrition, laboratory and imaging services, health logistics, ePharmacy, ePrescription, insurance and claims, medical devices, registries, and shared health records.

### Implementing Nigeria Core

**Profile Support:** A system uses Nigeria Core Profiles to represent administrative, clinical, registry, regulatory, or programme information consistently.

**Profile and Interaction Support:** A system supports both Nigeria Core Profile content and the defined RESTful interactions for exchanging that content.

See [Conformance Requirements](conformance.md) for the rules used to claim conformance.

### National Interoperability Context

Nigeria's digital health ecosystem includes systems operated by government institutions, states, health programmes, regulators, development partners, private providers, innovators, and vendors. Many were developed around separate programme requirements, creating differences in data models, identifiers, terminology, reporting formats, and integration methods.

Nigeria Core responds by providing a common FHIR-based foundation informed by Nigeria's digital health policies, the National Digital Health Architecture, national health data standards activities, the Nigeria FHIR Community, DHIN Connectathons, Standards Organisation of Nigeria processes, and implementation experience across priority health programmes.

It also supports the Nigeria [Shared Health Record](ng-ps.md), aligned where appropriate with the International Patient Summary, and interoperability with:

* Client, patient, facility, workforce, provider, and regulator registries
* Terminology, consent, privacy, and access-control services
* Programme repositories and public health reporting platforms
* Health information exchange services
* Conformance testing and sandbox environments

### How to Read This Guide

| | |
| :--- | :--- |
| [Conformance](conformance.md) | Conformance rules,[General requirements](general.md),[Must Support](general.md),[Clinical notes](clinical-notes.md),[Basic Provenance](provenance.md),[security](security.md)and[relationship with other IGs](other-igs.md). |
| [FHIR Artifacts](artifacts.md) | Formal profiles, extensions, logical models, and other FHIR artefacts. |
| [Search Parameters and Operations](index.md) | Nigeria Core operations and search parameters. |
| [Terminology](artifacts.md#terminology-value-sets) | CodeSystems, ValueSets, ConceptMaps, and terminology bindings. |
| [Capability Statements](index.md) | Expected server and client capabilities. |
| [Change Log](change-log.md)and[Roadmap](roadmap.md) | Release changes and future direction. |

### Nigeria Core Actors

The following actors define the principal roles participating in Nigeria Core FHIR exchanges. The actor definitions and associated capabilities are subject to stakeholder validation.

| | |
| :--- | :--- |
| [Nigeria Core Requestor](ActorDefinition-NgCoreRequestor.md) | Client application or service that initiates a Nigeria Core FHIR request. |
| [Nigeria Core Responder](ActorDefinition-NgCoreResponder.md) | Server, repository, or service that processes and responds to Nigeria Core FHIR requests. |
| [Nigeria Core Registry Service](ActorDefinition-NgCoreRegistryService.md) | Provides authoritative registry information about nationally governed entities. |
| [Nigeria Core Terminology Service](ActorDefinition-NgCoreTerminologyService.md) | Provides terminology validation, expansion, translation, lookup, and mapping services. |
| [Nigeria Core Conformance and Sandbox Service](ActorDefinition-NgCoreConformanceSandboxService.md) | Provides implementation testing, validation, test data, and conformance-support services. |

### Foundational Resources

These Nigeria Core profiles provide the patient, workforce, organisation, location, relationship, and encounter context required by HIV programme artefacts.

| | | |
| :--- | :--- | :--- |
| [NG Patient](StructureDefinition-ng-patient.md) | Represents an individual receiving health services and provides the core demographic, identification, contact, and administrative information required to link clinical and programme records across systems. | Systems exchanging patient-level data**SHALL**use this profile and populate all mandatory and Must Support elements relevant to the workflow. |
| [NG Practitioner](StructureDefinition-ng-practitioner.md) | Represents an individual health worker involved in delivering, documenting, reviewing, or supporting healthcare services, including clinicians, counsellors, pharmacists, laboratory personnel, and other authorised personnel. | Systems recording an individual health worker**SHALL**use this profile and preserve the practitioner's identifiers and professional details where available. |
| [NG PractitionerRole](StructureDefinition-ng-practitioner-role.md) | Describes the operational role of a practitioner within an organisation, including professional function, specialty, service, and location of practice. | Systems that exchange the practitioner's operational role**SHALL**use this profile and reference the associated Practitioner and Organization. |
| [NG RelatedPerson](StructureDefinition-ng-related-person.md) | Represents a person who has a defined relationship with a patient and may participate in care, support, consent, communication, or follow-up activities, such as a caregiver, guardian, treatment supporter, or next of kin. | Systems exchanging related-person information**SHALL**use this profile and**SHALL**limit disclosure to the authorised care or programme purpose. |
| [NG Organization](StructureDefinition-ng-organization.md) | Represents an organisational entity participating in healthcare delivery, administration, referral, diagnostics, pharmacy services, financing, public health programmes, or health information exchange. | Systems**SHALL**use this profile for participating organisations and**SHALL**use nationally governed identifiers where available. |
| [NG Location](StructureDefinition-ng-location.md) | Represents a physical, virtual, or service-delivery place associated with healthcare activities, including facilities, wards, clinics, laboratories, pharmacies, outreach sites, and specimen collection points. | Systems exchanging location information**SHALL**use this profile and reference the responsible Organization where applicable. |
| [NG Encounter](StructureDefinition-ng-encounter.md) | Represents a healthcare interaction between a patient and one or more service providers and provides the clinical and administrative context for observations, diagnoses, procedures, medications, laboratory activities, and other care events. | Clinical resources associated with a visit**SHOULD**reference a conformant encounter, and systems**SHALL**preserve encounter status, class, period, patient, and service location. |

### Administrative Terminology

These shared administrative terminology artefacts support consistent representation of locations, facilities, organisations, medicines, identifiers, relationships, provenance, and other common concepts. See the [Terminology](artifacts.md#terminology-value-sets) page for the complete catalogue.

#### Administrative ValueSets

| | |
| :--- | :--- |
| [NG HealthFacility Type VS](ValueSet-ng-facility-type-vs.md) | [NG LGAs VS](ValueSet-ng-lgas-vs.md) |
| [NG Local ATC — All Medications](ValueSet-ng-atc-all-medications-vs.md) | [NG Location Owner](ValueSet-ng-organization-owner-vs.md) |
| [NG Pharmacy Organization Types](ValueSet-ng-pharmacy-org-type-vs.md) | [NG Provenance Activity Codes](ValueSet-ng-provenance-activity-vs.md) |
| [NG Provider Organization Types](ValueSet-ng-provider-org-type-vs.md) | [NG Relationships VS](ValueSet-ng-relationships-vs.md) |
| [NG Sibling Health Status VS](ValueSet-ng-sibling-health-status-vs.md) | [NG States VS](ValueSet-ng-states-vs.md) |
| [NG Wards VS](ValueSet-ng-wards-vs.md) | [NG Yes/No Codes VS](ValueSet-ng-yes-no-vs.md) |
| [NG Target Population Category VS](ValueSet-ng-target-population-category-vs.md) |   |

#### Administrative CodeSystems

| | |
| :--- | :--- |
| [NG Administrative Wards CS](CodeSystem-ng-wards-cs.md) | [NG Age Component Codes](CodeSystem-age-component-codes-cs.md) |
| [NG Bundle Identifier Codes](CodeSystem-ng-bundle-identifier-cs.md) | [NG CarePlan Activity Codes](CodeSystem-ng-careplan-activity-cs.md) |
| [NG CarePlan Category Codes](CodeSystem-ng-careplan-category-cs.md) | [NG Claim Product/Service Codes](CodeSystem-ng-claim-product-or-service-cs.md) |
| [NG Facility Identifier CS](CodeSystem-ng-facility-identifier-cs.md) | [NG Facility Type CS](CodeSystem-ng-facility-type-cs.md) |
| [NG LGAs in Nigeria CS](CodeSystem-ng-lgas-cs.md) | [NG Languages in Nigeria CS](CodeSystem-nigeria-languages.md) |
| [NG Location Owner CS](CodeSystem-ng-organization-owner-cs.md) | [NG Local ATC Medication Codes](CodeSystem-ng-atc-medication-cs.md) |
| [NG Patient Identifier Type CS](CodeSystem-ng-patient-identifier-type-cs.md) | [NG Practitioner Identifier CS — MDCN](CodeSystem-ng-mdcn-cs.md) |
| [NG Practitioner Identifier CS — PCN](CodeSystem-ng-pcn-cs.md) | [NG Provenance Activity Codes](CodeSystem-ng-provenance-activity-cs.md) |
| [NG Relationships CS](CodeSystem-ng-relationship-cs.md) | [NG States in Nigeria CS](CodeSystem-ng-states-cs.md) |
| [Yes/No Codes](CodeSystem-ng-yes-no-cs.md) |   |

### Programme and Domain Implementation Guides

Nigeria Core provides reusable national profiles and terminology for programme-specific and domain-specific guides. These guides may introduce additional constraints, workflows, questionnaires, logical models, terminology, and transactions while retaining alignment with Nigeria Core.

### Standards, Governance, and Conformance

Nigeria Core supports harmonisation of Nigerian health data standards, reuse of appropriate international standards, mapping of Nigerian terminology and identifiers, vendor testing, standards-based procurement, and alignment among federal, state, programme, regulator, provider, and vendor systems.

The guide will evolve through stakeholder review, technical working groups, Connectathons, implementation feedback, formal standards processes—including the Standards Organisation of Nigeria—and real-world testing.

### Dependencies
















