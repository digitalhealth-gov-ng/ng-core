# NG IPS Composition - Nigeria Core - FHIR Implementation Guide v0.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NG IPS Composition**

## Resource Profile: NG IPS Composition 

| | |
| :--- | :--- |
| *Official URL*:https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-ips-composition | *Version*:0.0.0 |
| Active as of 2026-06-19 | *Computable Name*:NgIPSComposition |
| *Other Identifiers:*OID:2.16.840.1.113884.3.9944.1.42.39 | |

 
International Patient Summary (IPS) Composition adapted for Nigeria Core. Conforms to IPS v2 Composition and narrows key references to local NG profiles where available. Includes common IPS sections: Problems, Allergies, Medications, Immunizations, Procedures, Results, Devices, and Plan of Care. 

**Usages:**

* Use this Profile: [Bundle (IPS)](StructureDefinition-ng-ips-bundle.md)
* Refer to this Profile: [NG IPS Composition](StructureDefinition-ng-ips-composition.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ng.gov.digitalhealth.fhir-ig|current/StructureDefinition/StructureDefinition-ng-ips-composition.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ng-ips-composition.csv), [Excel](StructureDefinition-ng-ips-composition.xlsx), [Schematron](StructureDefinition-ng-ips-composition.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ng-ips-composition",
  "url" : "https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-ips-composition",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113884.3.9944.1.42.39"
  }],
  "version" : "0.0.0",
  "name" : "NgIPSComposition",
  "title" : "NG IPS Composition",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-19T12:50:07-04:00",
  "publisher" : "NDHI",
  "contact" : [{
    "name" : "NDHI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://digitalhealth.gov.ng"
    },
    {
      "system" : "email",
      "value" : "emeka2015@gmail.com"
    }]
  },
  {
    "name" : "Nigeria Digital in Health Initiative.",
    "telecom" : [{
      "system" : "email",
      "value" : "lekeojewale@gmail.com",
      "use" : "work"
    }]
  },
  {
    "name" : "Nigeria Digital in Health Initiative.",
    "telecom" : [{
      "system" : "email",
      "value" : "emeka2015@gmail.com",
      "use" : "work"
    }]
  }],
  "description" : "International Patient Summary (IPS) Composition adapted for Nigeria Core.\nConforms to IPS v2 Composition and narrows key references to local NG profiles where available.\nIncludes common IPS sections: Problems, Allergies, Medications, Immunizations, Procedures, Results, Devices, and Plan of Care. ",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "NG",
      "display" : "Nigeria"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "fhirdocumentreference",
    "uri" : "http://hl7.org/fhir/documentreference",
    "name" : "FHIR DocumentReference"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Composition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Composition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Composition.meta.profile",
      "path" : "Composition.meta.profile",
      "short" : "The conformance of this Composition to a specific IPS version.",
      "definition" : "The conformance of this Composition to a specific version of the IPS (e.g. http://hl7.org/fhir/uv/ips/StructureDefinition/Composition-uv-ips|2.0.0 for 2.0.0)",
      "mustSupport" : true
    },
    {
      "id" : "Composition.text",
      "path" : "Composition.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.identifier",
      "path" : "Composition.identifier",
      "mustSupport" : true
    },
    {
      "id" : "Composition.status",
      "path" : "Composition.status",
      "mustSupport" : true
    },
    {
      "id" : "Composition.type",
      "path" : "Composition.type",
      "short" : "Kind of composition (\"Patient Summary\")",
      "definition" : "Specifies that this composition refers to a Patient Summary (Loinc \"60591-5\")\r\n",
      "type" : [{
        "code" : "CodeableConcept",
        "profile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/CodeableConcept-ips"]
      }],
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "60591-5"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Composition.subject",
      "path" : "Composition.subject",
      "definition" : "Who or what the composition is about. \r\nIn general a composition can be about a person, (patient or healthcare practitioner), a device (e.g. a machine) or even a group of subjects (such as a document about a herd of livestock, or a set of patients that share a common exposure).\r\nFor the IPS the subject is always the patient.",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.subject.reference",
      "path" : "Composition.subject.reference",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.date",
      "path" : "Composition.date",
      "mustSupport" : true
    },
    {
      "id" : "Composition.author",
      "path" : "Composition.author",
      "short" : "Who and/or what authored the IPS",
      "comment" : "The distinction between the two types of IPS, \"human-curated\" or \"software-assembled\", is based on the authors recorded in this field: the author refers to humans (i.e. Practitioner, PractitionerRole, Patient, and/or RelatedPerson) if the IPS provenance is \"human-curated\", or devices (i.e. Device) if the IPS provenance is \"software-assembled\". In the case of a software-assembled IPS that is then verified by a human, the author would be the device that constructed the IPS document, but additional attesters would identity the humans who performed this check.",
      "mustSupport" : true
    },
    {
      "id" : "Composition.title",
      "path" : "Composition.title",
      "short" : "The title of this patient summary. This may include information like the patient name and time generated",
      "definition" : "Official human-readable label for the composition.\r\n\r\nThis would typically include a label of \"International Patient Summary\" or any equivalent translation and other relevant document information",
      "mustSupport" : true
    },
    {
      "id" : "Composition.attester",
      "path" : "Composition.attester",
      "mustSupport" : true
    },
    {
      "id" : "Composition.attester.mode",
      "path" : "Composition.attester.mode",
      "mustSupport" : true
    },
    {
      "id" : "Composition.attester.time",
      "path" : "Composition.attester.time",
      "mustSupport" : true
    },
    {
      "id" : "Composition.attester.party",
      "path" : "Composition.attester.party",
      "mustSupport" : true
    },
    {
      "id" : "Composition.custodian",
      "path" : "Composition.custodian",
      "mustSupport" : true
    },
    {
      "id" : "Composition.relatesTo.target[x]",
      "path" : "Composition.relatesTo.target[x]",
      "type" : [{
        "code" : "Identifier"
      },
      {
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Composition",
        "https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-ips-composition"]
      }]
    },
    {
      "id" : "Composition.event",
      "path" : "Composition.event",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "code"
        }],
        "rules" : "open"
      },
      "definition" : "The main activity being described by a IPS is the provision of healthcare over a period of time. \r\nIn the CDA representation of the IPS this is shown by setting the value of serviceEvent/@classCode to “PCPR” (care provision) and indicating the duration over which care was provided in serviceEvent/effectiveTime. \r\nIn the FHIR representation at least one event should be used to record this information.\r\nAdditional data from outside this duration may also be included if it is relevant to care provided during that time range (e.g., reviewed during the stated time range). For example if the IPS is generated by a GP based on information recorded in his/her EHR-S, then the start value should represent the date when the treatment relationship between the patient and the GP started; and the end value the date of the latest care event."
    },
    {
      "id" : "Composition.event:careProvisioningEvent",
      "path" : "Composition.event",
      "sliceName" : "careProvisioningEvent",
      "short" : "The care provisioning being documented",
      "definition" : "The provision of healthcare over a period of time this IPS is documenting.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.event:careProvisioningEvent.code",
      "path" : "Composition.event.code",
      "min" : 1,
      "max" : "1",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActClass",
          "code" : "PCPR"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Composition.event:careProvisioningEvent.period",
      "path" : "Composition.event.period",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section",
      "path" : "Composition.section",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "code"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "short" : "Sections composing the IPS",
      "definition" : "The root of the sections that make up the IPS composition.",
      "min" : 3,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section.title",
      "path" : "Composition.section.title",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section.text",
      "path" : "Composition.section.text",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section.section",
      "path" : "Composition.section.section",
      "max" : "0"
    },
    {
      "id" : "Composition.section:sectionProblems",
      "path" : "Composition.section",
      "sliceName" : "sectionProblems",
      "short" : "IPS Problems Section",
      "definition" : "The IPS problem section lists and describes clinical problems or conditions currently being monitored for the patient.",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionProblems.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11450-4"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionProblems.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Clinical problems or conditions currently being monitored for the patient.",
      "definition" : "It lists and describes clinical problems or conditions currently being monitored for the patient.  This entry shall be used to document that no information about problems is available, or that no relevant problems are known.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-condition",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionProblems.entry:problem",
      "path" : "Composition.section.entry",
      "sliceName" : "problem",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-condition"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionProblems.emptyReason",
      "path" : "Composition.section.emptyReason",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionAllergies",
      "path" : "Composition.section",
      "sliceName" : "sectionAllergies",
      "short" : "IPS Allergies and Intolerances Section",
      "definition" : "This section documents the relevant allergies or intolerances for that patient, describing the kind of reaction (e.g. rash, anaphylaxis,..); preferably the agents that cause it; and optionally the criticality and the certainty of the allergy.\r\nAt a minimum, it should list currently active and any relevant historical allergies and adverse reactions.\r\nIf no information about allergies is available, or if no allergies are known this should be clearly documented in the section.",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionAllergies.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "48765-2"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionAllergies.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Relevant allergies or intolerances for that patient.",
      "definition" : "It lists the relevant allergies or intolerances for that patient, describing the kind of reaction (e.g. rash, anaphylaxis,..); preferably the agents that cause it; and optionally the criticality and the certainty of the allergy.\r\nAt a minimum, it should list currently active and any relevant historical allergies and adverse reactions.\r\n This entry shall be used to document that no information about allergies is available, or that no allergies are known .",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/AllergyIntolerance",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionAllergies.entry:allergyOrIntolerance",
      "path" : "Composition.section.entry",
      "sliceName" : "allergyOrIntolerance",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/AllergyIntolerance"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionAllergies.emptyReason",
      "path" : "Composition.section.emptyReason",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionMedications",
      "path" : "Composition.section",
      "sliceName" : "sectionMedications",
      "short" : "IPS Medication Summary Section",
      "definition" : "The medication summary section contains a description of the patient's medications relevant for the scope of the patient summary.\r\nThe actual content could depend on the jurisdiction, it could report:\r\n- the currently active medications; \r\n- the current and past medications considered relevant by the authoring GP; \r\n- the patient prescriptions or dispensations automatically extracted by a regional or a national EHR.\r\n\r\nIn those cases medications are documented in the Patient Summary as medication statements or medication requests.\r\nThis section requires either an entry indicating the subject is known not to be on any relevant medication; either an entry indicating that no information is available about medications; or entries summarizing the subject's relevant medications.",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionMedications.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10160-0"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionMedications.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Medications relevant for the scope of the patient summary",
      "definition" : "This list the medications relevant for the scope of the patient summary or it is used to indicate that the subject is known not to be on any relevant medication; either that no information is available about medications.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/MedicationStatement",
        "https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-medication-request",
        "http://hl7.org/fhir/StructureDefinition/MedicationAdministration",
        "https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-medication-dispense",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionMedications.entry:medicationStatementOrRequest",
      "path" : "Composition.section.entry",
      "sliceName" : "medicationStatementOrRequest",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/MedicationStatement",
        "https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-medication-request"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionMedications.emptyReason",
      "path" : "Composition.section.emptyReason",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionImmunizations",
      "path" : "Composition.section",
      "sliceName" : "sectionImmunizations",
      "short" : "IPS Immunizations Section",
      "definition" : "The Immunizations Section defines a patient's current immunization status and pertinent immunization history.\r\nThe primary use case for the Immunization Section is to enable communication of a patient's immunization status.\r\nThe section includes the current immunization status, and may contain the entire immunization history that is relevant to the period of time being summarized.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionImmunizations.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11369-6"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionImmunizations.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Patient's immunization status and pertinent history.",
      "definition" : "It defines the patient's current immunization status and pertinent immunization history.\r\nThe primary use case for the Immunization Section is to enable communication of a patient's immunization status.\r\nIt may contain the entire immunization history that is relevant to the period of time being summarized. This entry shall be used to document that no information about immunizations is available, or that no immunizations are known.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-immunization",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionImmunizations.entry:immunization",
      "path" : "Composition.section.entry",
      "sliceName" : "immunization",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-immunization"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionResults",
      "path" : "Composition.section",
      "sliceName" : "sectionResults",
      "short" : "IPS Results Section",
      "definition" : "This section assembles relevant observation results collected on the patient or produced on in-vitro biologic specimens collected from the patient. Some of these results may be laboratory results, others may be anatomic pathology results, others, radiology results, and others, clinical results.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionResults.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "30954-2"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionResults.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "resolve()"
        },
        {
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Relevant observation results collected on the patient or produced on in-vitro biologic specimens collected from the patient.",
      "definition" : "Relevant observation results collected on the patient or produced on in-vitro biologic specimens collected from the patient. Some of these results may be laboratory results, others may be anatomic pathology results, others, radiology results, and others, clinical results.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Observation",
        "https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-diagnostic-report",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionResults.entry:results-observation-laboratory-pathology",
      "path" : "Composition.section.entry",
      "sliceName" : "results-observation-laboratory-pathology",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-observation-results-laboratory-pathology"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionResults.entry:results-observation-radiology",
      "path" : "Composition.section.entry",
      "sliceName" : "results-observation-radiology",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-observation-results-radiology"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionResults.entry:results-diagnosticReport",
      "path" : "Composition.section.entry",
      "sliceName" : "results-diagnosticReport",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-diagnostic-report"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionProceduresHx",
      "path" : "Composition.section",
      "sliceName" : "sectionProceduresHx",
      "short" : "IPS History of Procedures Section",
      "definition" : "The History of Procedures Section contains a description of the patient past procedures that are pertinent to the scope of this document.\r\nProcedures may refer for example to:\r\n1. Invasive Diagnostic procedure:e.g. Cardiac catheterization; (the results of these procedure are documented in the results section)\r\n2. Therapeutic procedure: e.g. dialysis;\r\n3. Surgical procedure: e.g. appendectomy",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionProceduresHx.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "47519-4"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionProceduresHx.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Patient past procedures pertinent to the scope of this document.",
      "definition" : "It lists the patient past procedures that are pertinent to the scope of this document.\r\nProcedures may refer for example to:\r\n1. Invasive Diagnostic procedure:e.g. Cardiac catheterization; (the results of these procedure are documented in the results section)\r\n2. Therapeutic procedure: e.g. dialysis;\r\n3. Surgical procedure: e.g. appendectomy. This entry shall be used to document that no information about past procedures is available, or that no relevant past procedures are known.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Procedure",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionProceduresHx.entry:procedure",
      "path" : "Composition.section.entry",
      "sliceName" : "procedure",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Procedure"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionMedicalDevices",
      "path" : "Composition.section",
      "sliceName" : "sectionMedicalDevices",
      "short" : "IPS Medical Devices Section",
      "definition" : "The medical devices section contains narrative text and coded entries describing the patient history of medical device use.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionMedicalDevices.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "46264-8"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionMedicalDevices.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Patient history of medical device use.",
      "definition" : "It describes the patient history of medical device use. This entry shall be used to document that no information about medical device use is available, or that no relevant medical device use is known.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/DeviceUseStatement",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionMedicalDevices.entry:deviceStatement",
      "path" : "Composition.section.entry",
      "sliceName" : "deviceStatement",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/DeviceUseStatement"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionAdvanceDirectives",
      "path" : "Composition.section",
      "sliceName" : "sectionAdvanceDirectives",
      "short" : "IPS Advance Directives Section",
      "definition" : "The advance directives section contains a narrative description of patient's advance directive.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionAdvanceDirectives.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "42348-3"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionAdvanceDirectives.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Narrative description of the patient's advance directive.",
      "definition" : "Contains a narrative description or a Consent entry with information about the patient's advance directive.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Consent",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionAdvanceDirectives.entry:advanceDirectivesConsent",
      "path" : "Composition.section.entry",
      "sliceName" : "advanceDirectivesConsent",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Consent"]
      }]
    },
    {
      "id" : "Composition.section:sectionAlerts",
      "path" : "Composition.section",
      "sliceName" : "sectionAlerts",
      "short" : "IPS Alerts Section",
      "definition" : "The alerts section flags potential concerns and/or dangers to/from the patient and may also include obstacles to care.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionAlerts.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "104605-1"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionAlerts.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Alert information.",
      "definition" : "Contains alert information to be communicated. May optionally reference other resources in IPS.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Flag",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionAlerts.entry:alertsFlag",
      "path" : "Composition.section.entry",
      "sliceName" : "alertsFlag",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Flag"]
      }]
    },
    {
      "id" : "Composition.section:sectionFunctionalStatus",
      "path" : "Composition.section",
      "sliceName" : "sectionFunctionalStatus",
      "short" : "IPS Functional Status",
      "definition" : "The functional status section shall contain a narrative description of capability of the patient to perform acts of daily living, including possible needs of the patient to be continuously assessed by third parties. The invalidity status may in fact influence decisions about how to administer treatments.\r\nProfiles to express disabilities and functional assessments will be specified by future versions of this guide.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionFunctionalStatus.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "47420-5"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionFunctionalStatus.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Optional entry used to represent disabilities and functional assessments",
      "definition" : "It describes capabilities of the patient to perform acts of daily living, including possible needs of the patient to be continuously assessed by third parties. The invalidity status may in fact influence decisions about how to administer treatments.\r\nProfiles to express disabilities and functional assessments will be specified by future versions of this guide.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Condition",
        "http://hl7.org/fhir/StructureDefinition/ClinicalImpression",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionFunctionalStatus.entry:disability",
      "path" : "Composition.section.entry",
      "sliceName" : "disability",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-condition"]
      }]
    },
    {
      "id" : "Composition.section:sectionFunctionalStatus.entry:functionalAssessment",
      "path" : "Composition.section.entry",
      "sliceName" : "functionalAssessment",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/ClinicalImpression"]
      }]
    },
    {
      "id" : "Composition.section:sectionPastProblems",
      "path" : "Composition.section",
      "sliceName" : "sectionPastProblems",
      "short" : "IPS History of Past Problems Section",
      "definition" : "The History of Past Problems section contains a description of the conditions the patient suffered in the past but no longer tracked in the Problem List.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionPastProblems.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11348-0"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionPastProblems.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Conditions the patient suffered in the past.",
      "definition" : "It contains a description of the conditions the patient suffered in the past.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Condition",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionPastProblems.entry:pastProblem",
      "path" : "Composition.section.entry",
      "sliceName" : "pastProblem",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-condition"]
      }]
    },
    {
      "id" : "Composition.section:sectionPregnancyHx",
      "path" : "Composition.section",
      "sliceName" : "sectionPregnancyHx",
      "short" : "IPS History of Pregnancy Section",
      "definition" : "The history of pregnancy section shall contain information about whether the patient is currently pregnant or not.\r\nIt may contain addition summarizing information about the outcome of earlier pregnancies.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionPregnancyHx.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10162-6"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionPregnancyHx.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Current pregnancy status and, optionally, information about the outcome of earlier pregnancies.",
      "definition" : "It contains information about whether the patient is currently pregnant or not.\r\nIt may contain addition summarizing information about the outcome of earlier pregnancies.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Observation",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionPregnancyHx.entry:pregnancyStatus",
      "path" : "Composition.section.entry",
      "sliceName" : "pregnancyStatus",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-observation-pregnancy-status"]
      }]
    },
    {
      "id" : "Composition.section:sectionPregnancyHx.entry:pregnancyOutcome",
      "path" : "Composition.section.entry",
      "sliceName" : "pregnancyOutcome",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-observation-pregnancy-outcome"]
      }]
    },
    {
      "id" : "Composition.section:sectionPatientStory",
      "path" : "Composition.section",
      "sliceName" : "sectionPatientStory",
      "short" : "IPS Patient Story Section",
      "definition" : "The section contains narrative text along with optional resources that express what matters to a patient. This may include needs, strengths, values, concerns and preferences to others providing support and care. The patient’s story, provided here, may be told by the patient or by a proxy.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionPatientStory.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "81338-6"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionPatientStory.entry",
      "path" : "Composition.section.entry",
      "short" : "Patient Story resources.",
      "definition" : "Contains resources to support the Patient Story. Instances of DocumentReference or any other suitable resource type may be used."
    },
    {
      "id" : "Composition.section:sectionPlanOfCare",
      "path" : "Composition.section",
      "sliceName" : "sectionPlanOfCare",
      "short" : "IPS Plan of Care Section",
      "definition" : "The plan of care section contains a narrative description of the expectations for care including proposals, goals, and order requests for monitoring, tracking, or improving the condition of the patient.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionPlanOfCare.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "18776-5"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionPlanOfCare.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Optional entry used to represent structured care plans",
      "definition" : "Dynamic, personalized plan including identified needed healthcare activity, health objectives and healthcare goals, relating to one or more specified health issues in a healthcare process [Source EN ISO 13940]",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/CarePlan",
        "http://hl7.org/fhir/StructureDefinition/ImmunizationRecommendation",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionPlanOfCare.entry:carePlan",
      "path" : "Composition.section.entry",
      "sliceName" : "carePlan",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/CarePlan"]
      }]
    },
    {
      "id" : "Composition.section:sectionPlanOfCare.entry:immunizationRecommendation",
      "path" : "Composition.section.entry",
      "sliceName" : "immunizationRecommendation",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/ImmunizationRecommendation"]
      }]
    },
    {
      "id" : "Composition.section:sectionSocialHistory",
      "path" : "Composition.section",
      "sliceName" : "sectionSocialHistory",
      "short" : "IPS Social History Section",
      "definition" : "The social history section contains a description of the person’s Health related \"lifestyle factors\" or \"lifestyle observations\" (e.g. smoke habits; alcohol consumption; diets, risky habits.)",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionSocialHistory.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29762-2"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionSocialHistory.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Health related \"lifestyle factors\" or \"lifestyle observations\" (e.g. smoke habits; alcohol consumption; diets, risky habits.)",
      "definition" : "Description of the person’s Health related “lifestyle factors\" or \"lifestyle observations\" (e.g. smoke habits; alcohol consumption; diets, risky habits.)",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Observation",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionSocialHistory.entry:smokingTobaccoUse",
      "path" : "Composition.section.entry",
      "sliceName" : "smokingTobaccoUse",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-observation-tobacco-use"]
      }]
    },
    {
      "id" : "Composition.section:sectionSocialHistory.entry:alcoholUse",
      "path" : "Composition.section.entry",
      "sliceName" : "alcoholUse",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir-ig.digitalhealth.gov.ng/StructureDefinition/ng-observation-alcohol-use"]
      }]
    },
    {
      "id" : "Composition.section:sectionVitalSigns",
      "path" : "Composition.section",
      "sliceName" : "sectionVitalSigns",
      "label" : "Vital signs",
      "short" : "IPS Vital Signs Section",
      "definition" : "The Vital signs section includes blood pressure, body temperature, heart rate, and respiratory rate. It may also include other clinical findings, such as height, weight, body mass index, head circumference, and pulse oximetry. In particular, notable vital signs or physical findings such as the most recent, maximum and/or minimum, baseline, or relevant trends may be included",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:sectionVitalSigns.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "8716-3"
        }]
      }
    },
    {
      "id" : "Composition.section:sectionVitalSigns.entry",
      "path" : "Composition.section.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "open"
      },
      "short" : "Notable vital signs or physical findings.",
      "definition" : "Notable vital signs or physical findings as: blood pressure, body temperature, heart rate, and respiratory rate. It may also include other clinical findings, such as height, weight, body mass index, head circumference, and pulse oximetry. In particular, notable vital signs or physical findings such as the most recent, maximum and/or minimum, baseline, or relevant trends may be included",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Observation",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Composition.section:sectionVitalSigns.entry:vitalSign",
      "path" : "Composition.section.entry",
      "sliceName" : "vitalSign",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/vitalsigns"]
      }]
    }]
  }
}

```
