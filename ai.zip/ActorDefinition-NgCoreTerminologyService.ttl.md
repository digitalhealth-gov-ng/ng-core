# NG Terminology Service - TTL Representation - Nigeria Core - FHIR Implementation Guide v0.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NG Terminology Service**

## : NG Terminology Service - TTL Representation

| |
| :--- |
| Draft as of 2026-08-12 |

[Raw ttl](ActorDefinition-NgCoreTerminologyService.ttl) | [Download](ActorDefinition-NgCoreTerminologyService.ttl)

