# NG Vaccine Local ValueSet - Nigeria Core - FHIR Implementation Guide v0.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NG Vaccine Local ValueSet**

## ValueSet: NG Vaccine Local ValueSet 

| | |
| :--- | :--- |
| *Official URL*:https://fhir-ig.digitalhealth.gov.ng/ValueSet/ng-vaccine-local-vs | *Version*:0.0.0 |
| Active as of 2026-08-12 | *Computable Name*:NgVaccineLocalVS |
| *Other Identifiers:*OID:2.16.840.1.113884.3.9944.1.48.206 | |

 
All local vaccine codes (DE1–DE29). 

 **References** 

* [NG Immunization](StructureDefinition-ng-immunization.md)
* [NG Immunization Administer Vaccine Form](Questionnaire-ng-imm-administer-vaccine-form.md)
* [NG Immunization Defaulter Tracking Form](Questionnaire-ng-imm-defaulter-tracking-form.md)
* [NG Immunization Manage AEFI Form](Questionnaire-ng-imm-manage-aefi-form.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ng-vaccine-local-vs",
  "url" : "https://fhir-ig.digitalhealth.gov.ng/ValueSet/ng-vaccine-local-vs",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113884.3.9944.1.48.206"
  }],
  "version" : "0.0.0",
  "name" : "NgVaccineLocalVS",
  "title" : "NG Vaccine Local ValueSet",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-12T13:22:49+01:00",
  "publisher" : "NDHI",
  "contact" : [{
    "name" : "NDHI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://digitalhealth.gov.ng"
    },
    {
      "system" : "email",
      "value" : "emeka2015@gmail.com"
    }]
  },
  {
    "name" : "Nigeria Digital in Health Initiative.",
    "telecom" : [{
      "system" : "email",
      "value" : "lekeojewale@gmail.com",
      "use" : "work"
    }]
  },
  {
    "name" : "Nigeria Digital in Health Initiative.",
    "telecom" : [{
      "system" : "email",
      "value" : "emeka2015@gmail.com",
      "use" : "work"
    }]
  }],
  "description" : "All local vaccine codes (DE1–DE29).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "NG",
      "display" : "Nigeria"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://fhir-ig.digitalhealth.gov.ng/CodeSystem/ng-vaccine-local"
    }]
  }
}

```
